program Sokoban;

{$R *.dres}

uses
  Vcl.Forms,
  USokoban in 'USokoban.pas' {FSokoban},
  Vcl.Themes,
  Vcl.Styles,
  GSokoban in 'GSokoban.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.Title := 'Sokoban';
  TStyleManager.TrySetStyle('Windows11 Modern Light');
  Application.CreateForm(TFSokoban, FSokoban);
  Application.Run;
end.
