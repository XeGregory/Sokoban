unit USokoban;

interface

uses
  Winapi.Windows, Winapi.Messages,

  System.SysUtils, System.Variants, System.Classes,

  Vcl.Graphics, Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.ExtCtrls, Vcl.Menus;

type
  TFSokoban = class(TForm)
    MainMenu: TMainMenu;
    MainGame: TMenuItem;
    NewGame: TMenuItem;
    N1: TMenuItem;
    QuitGame: TMenuItem;
    MainLevel: TMenuItem;
    SolverLevel: TMenuItem;
    UndoMove: TMenuItem;
    RestartLevel: TMenuItem;
    SkinLevel: TMenuItem;
    MainDebug: TMenuItem;
    Game: TImage;
    N2: TMenuItem;
    LevelByIndex: TMenuItem;
    NextLevel: TMenuItem;
    PreviousLevel: TMenuItem;
    MainAbout: TMenuItem;
    InfoLevel: TMenuItem;
    InfoPoints: TMenuItem;
    InfoGame: TMenuItem;
    ShareLevel: TMenuItem;
    IndSolverLevel: TMenuItem;

    { Form Create }
    procedure FormCreate(Sender: TObject);
    { Form Destroy }
    procedure FormDestroy(Sender: TObject);
    { Form CloseQuery }
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    { Form KeyDown }
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    { Game MouseDown }
    procedure GameMouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState;
      X, Y: Integer);
    { NewGame Click }
    procedure NewGameClick(Sender: TObject);
    { QuitGame Click }
    procedure QuitGameClick(Sender: TObject);
    { IndSolverLevel Click }
    procedure IndSolverLevelClick(Sender: TObject);
    { SolverLevel Click }
    procedure SolverLevelClick(Sender: TObject);
    { UndoMove Click }
    procedure UndoMoveClick(Sender: TObject);
    { RestartLevel Click }
    procedure RestartLevelClick(Sender: TObject);
    { ShareLevel Click }
    procedure ShareLevelClick(Sender: TObject);
    { SkinLevel Click }
    procedure SkinLevelClick(Sender: TObject);
    { LevelByIndex Click }
    procedure LevelByIndexClick(Sender: TObject);
    { NextLevel Click }
    procedure NextLevelClick(Sender: TObject);
    { PreviousLevel Click }
    procedure PreviousLevelClick(Sender: TObject);
    { InfoGame Click }
    procedure InfoGameClick(Sender: TObject);
    { InfoLevel Click }
    procedure InfoLevelClick(Sender: TObject);
    { InfoPoints Click }
    procedure InfoPointsClick(Sender: TObject);

  private { D�clarations priv�es }

  end;

var
  FSokoban: TFSokoban;

implementation

uses GSokoban;

{$R *.dfm}

var
  Sokoban: TSokoban;

  { Form Create }
procedure TFSokoban.FormCreate(Sender: TObject);
begin
  DoubleBuffered := True;
  KeyPreview := True;

{$IFDEF DEBUG}
  MainDebug.Visible := True;
  Caption := Application.Title + ' (Mode DEBUG)';
{$ELSE}
  MainDebug.Visible := False;
{$ENDIF}
  try
    Sokoban := TSokoban.Create(Game);
    Sokoban.LoadGameFromRegistry;
  except
    on E: Exception do
      ShowMessage(E.Message);
  end;
end;

{ Form Destroy }
procedure TFSokoban.FormDestroy(Sender: TObject);
begin
  if Assigned(Sokoban) then
    Sokoban.Free;
end;

{ Form CloseQuery }
procedure TFSokoban.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
begin
  if Assigned(Sokoban) then
{$IFDEF RELEASE}
    Sokoban.SaveGameToRegistry;
{$ENDIF}
  CanClose := True;
end;

{ Form KeyDown }
procedure TFSokoban.FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
begin
  if Assigned(Sokoban) then
  begin
    case Key of
      VK_UP:
        Sokoban.MovePlayer(0, -1);
      VK_DOWN:
        Sokoban.MovePlayer(0, 1);
      VK_LEFT:
        Sokoban.MovePlayer(-1, 0);
      VK_RIGHT:
        Sokoban.MovePlayer(1, 0);
    end;

    Sokoban.DrawGame;
  end;
end;

{ Game MouseDown }
procedure TFSokoban.GameMouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState;
  X, Y: Integer);
begin
  if Assigned(Sokoban) then
  begin
    Sokoban.HandleMouseClick(X, Y);
    Sokoban.DrawGame;
  end;
end;

{ NewGame Click }
procedure TFSokoban.NewGameClick(Sender: TObject);
begin
  if Assigned(Sokoban) then
  begin
    Sokoban.ResetGameToRegistry;
    Sokoban.LoadGameFromRegistry;
  end;
end;

{ QuitGame Click }
procedure TFSokoban.QuitGameClick(Sender: TObject);
begin
  if Assigned(Sokoban) then
    Sokoban.SaveGameToRegistry;

  Close;
end;

{ IndSolverLevel Click }
procedure TFSokoban.IndSolverLevelClick(Sender: TObject);
begin
  if Assigned(Sokoban) then
    Sokoban.Solveur;
  Sokoban.IndSolveur;
end;

{ SolverLevel Click }
procedure TFSokoban.SolverLevelClick(Sender: TObject);
begin
  if Assigned(Sokoban) then
    Sokoban.Solveur;
end;

{ UndoMove Click }
procedure TFSokoban.UndoMoveClick(Sender: TObject);
begin
  if Assigned(Sokoban) then
    Sokoban.UndoMove;
end;

{ RestartLevel Click }
procedure TFSokoban.RestartLevelClick(Sender: TObject);
begin
  if Assigned(Sokoban) then
    Sokoban.RestartLevel;
end;

{ ShareLevel Click }
procedure TFSokoban.ShareLevelClick(Sender: TObject);
begin
  if Assigned(Sokoban) then
    Sokoban.ShareLevelImage;
end;

{ SkinLevel Click }
procedure TFSokoban.SkinLevelClick(Sender: TObject);
var
  Skin: Integer;
begin
  if Assigned(Sokoban) then
  begin
    Skin := StrToInt(Copy(Sokoban.GetSkin, Length(Sokoban.GetSkin), 1));

    Inc(Skin);
    if Skin > 5 then
      Skin := 1;

    Sokoban.ChangeSkinSprite('Skin' + IntToStr(Skin));
  end;
end;

{ LevelByIndex Click }
procedure TFSokoban.LevelByIndexClick(Sender: TObject);
var
  Lvl: string;
begin
  if Assigned(Sokoban) and InputQuery('Sokoban', 'Niveau :', Lvl) then
    try
      Sokoban.LevelByIndex(StrToInt(Lvl) - 1);
    except
      on E: Exception do
      begin
        Sokoban.DrawGame;
        ShowMessage(E.Message);
      end;
    end;
end;

{ NextLevel Click }
procedure TFSokoban.NextLevelClick(Sender: TObject);
begin
  if Assigned(Sokoban) then
    Sokoban.NextLevel;
end;

{ NextLevel Click }
procedure TFSokoban.PreviousLevelClick(Sender: TObject);
begin
  if Assigned(Sokoban) then
    Sokoban.PreviousLevel;
end;

{ InfoGame Click }
procedure TFSokoban.InfoGameClick(Sender: TObject);
begin
  with TStringList.Create do
  begin
    Add('Le Sokoban est un jeu de puzzle classique o� le joueur contr�le un personnage qui ' + #13 +
      ' doit pousser des bo�tes vers des emplacements de stockage d�sign�s. ');
    Add('');
    Add('Le jeu se joue sur une carte bas�e sur une grille o� le personnage peut se d�placer ' + #13
      + ' dans quatre directions (Haut, Bas, Gauche, Droite).');
    Add('');
    Add('Le personnage ne peut pousser qu�une seule bo�te � la fois et il ne peut pas tirer ' + #13
      + ' les bo�tes ou passer � travers les murs.');
    ShowMessage(Text);
    Free;
  end;
end;

{ InfoLevel Click }
procedure TFSokoban.InfoLevelClick(Sender: TObject);
begin
  with TStringList.Create do
  begin
    Add('Niveaux de difficult� :');
    Add('');
    Add('# Facile : 2 .. 20 ~ Pushes');
    Add('# Moyen : 20 .. 40 ~ Pushes');
    Add('# Difficile : 40 .. 60 ~ Pushes');
    Add('# Tr�s difficile : 60 .. 80 ~ Pushes');
    Add('# Extr�me : 80 .. 100  ~ Pushes');
    Add('# Hard : 100 .. 200 ~ Pushes');
    Add('# D�mon : 200 .. 250 ~ Pushes');
    ShowMessage(Text);
    Free;
  end;
end;

{ InfoPoints Click }
procedure TFSokoban.InfoPointsClick(Sender: TObject);
begin
  with TStringList.Create do
  begin
    Add('Points d' + #39 + 'exp�rience (XP)');
    Add('');
    Add('# Facile : +1 XP');
    Add('# Moyen : +2 XP');
    Add('# Difficile : +4 XP');
    Add('# Tr�s difficile : +6 XP');
    Add('# Extr�me : +8 XP');
    Add('# Hard : +10 XP');
    Add('# D�mon : +12 XP');
    Add('');
    Add('# Retour en arri�re : -1 XP');
    Add('# Indice de niveau : -(Pushes / 2) XP');
    Add('# R�soudre le niveau : -(Pushes) XP');
    Add('# Limite de d�placement atteinte : -2 XP');

    ShowMessage(Text);
    Free;
  end;
end;

end.
