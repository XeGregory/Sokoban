﻿unit GSokoban;

interface

uses
  Winapi.Windows, Winapi.ShellAPI, Winapi.MMSystem,

  System.Classes, System.SysUtils, System.Generics.Collections, System.JSON, System.Win.Registry,
  System.IOUtils,

  Vcl.Graphics, Vcl.ExtCtrls, Vcl.Dialogs, Vcl.Themes, Vcl.Controls, Vcl.Forms;

type
  TPlayerDirection = (pdUp, pdDown, pdLeft, pdRight);
  TAnimationDirection = (adLeftToRight, adRightToLeft);

  TCoord = record
    X: Integer;
    Y: Integer;
  end;

  TSokoban = class
  private
    // Attributs et ressources graphiques
    FImage: TImage;
    FMap: array of array of Char;
    FTileWidth: Integer;
    FTileHeight: Integer;
    FPlayerBmpUp: TBitmap;
    FPlayerBmpDown: TBitmap;
    FPlayerBmpLeft: TBitmap;
    FPlayerBmpRight: TBitmap;
    FBoxBmp: TBitmap;
    FBoxOnTargetBmp: TBitmap;
    FTargetBmp: TBitmap;
    FWallBmp: TBitmap;
    FFloorBmp: TBitmap;
    FPlayerDirection: TPlayerDirection;
    FPlayerPos: TCoord;
    FMoveCount: Integer;
    FMapBackup: array of array of Char;
    FPlayerPosBackup: TCoord;
    FMoveCountBackup: Integer;
    FSpriteSheet: TBitmap;
    FAnimTimer: TTimer;
    FAnimDirection: TAnimationDirection;
    FAnimX: Integer;
    FAnimCurrentFrame: Integer;
    FAnimBmp1, FAnimBmp2: TBitmap;
    FAnimFrameWidth: Integer;
    FAnimFrameHeight: Integer;
    FCurrentLevel: Integer;
    FLevelsCount: Integer;
    FSkin: string;
    FJSONResourceName: string;
    FSolveur: string;
    FPoints: Integer;
    FPointLevel: Integer;
    FUsedAutoSolver: Boolean;

    { Méthodes internes de découpage et d’affichage }
    procedure LoadSprite(var Destination: TBitmap; const SrcRect: TRect);
    function GetPlayerBitmap: TBitmap;
    procedure DrawText(const AText: string);
    procedure DrawBottomText(const AText: string);
    procedure DrawPoints;

    { Méthodes d’animation }
    procedure AnimBottomTimer(Sender: TObject);
    procedure LoadAnimationImagesFromSprite;
    procedure StartBottomAnimation(const ADirection: TAnimationDirection);
    procedure WaitForAnimation;
    procedure PlayMoveSound(const ResName: string);

    { Méthodes spécifiques au jeu }
    function IsLevelCompleted: Boolean;
    function GetDifficultyLevel: string;
    procedure InternalLoadLevel(LevelIndex: Integer);
    function GetPlayerDirection: TPlayerDirection;

    { Procédures rendues privées }
    procedure LoadResourcesFromSpriteSheet(ASkin: String);
    procedure LoadLevel(const ALevel: array of string);
    procedure UpdateGame;
    procedure SaveUndoState;
    procedure LoadLevelFromJSONResource(LevelIndex: Integer);
  public
    GetSkin: String;
    constructor Create(Image: TImage);
    destructor Destroy; override;

    { Méthodes d'interaction et d'affichage public }
    procedure DrawGame;
    procedure ChangeSkinSprite(const ASkinResourceName: string);
    procedure HandleMouseClick(X, Y: Integer);
    procedure MovePlayer(DeltaX, DeltaY: Integer);
    procedure UndoMove;
    procedure ResetGameToRegistry;
    procedure LoadGameFromRegistry;
    procedure SaveGameToRegistry;
    procedure NextLevel;
    procedure PreviousLevel;
    procedure LevelByIndex(Level: Integer);
    procedure RestartLevel;
    procedure Solveur;
    procedure IndSolveur;
    procedure ShareLevelImage;
  end;

implementation

const
  DX: array [0 .. 3] of Integer = (0, 0, 1, -1);
  DY: array [0 .. 3] of Integer = (1, -1, 0, 0);

  { ------------------------------------------------------------------- }
  { CONSTRUCTEUR / DESTRUCTEUR ET GESTION DES RESSOURCES }
  { ------------------------------------------------------------------- }
constructor TSokoban.Create(Image: TImage);
begin
  inherited Create;
  FImage := Image;
  FImage.Picture.Bitmap.Width := FImage.Width;
  FImage.Picture.Bitmap.Height := FImage.Height;
  // Dimensionnement des tuiles et frames d'animation
  FTileWidth := 46;
  FTileHeight := 46;
  FAnimFrameWidth := 60;
  FAnimFrameHeight := 46;
  FPlayerDirection := pdDown;
  FCurrentLevel := 0;
  FLevelsCount := 0;
  FJSONResourceName := '';
  FSolveur := '';
  FPoints := 0;
  FUsedAutoSolver := False;

  // Création des objets graphiques
  FPlayerBmpUp := TBitmap.Create;
  FPlayerBmpDown := TBitmap.Create;
  FPlayerBmpLeft := TBitmap.Create;
  FPlayerBmpRight := TBitmap.Create;
  FBoxBmp := TBitmap.Create;
  FBoxOnTargetBmp := TBitmap.Create;
  FTargetBmp := TBitmap.Create;
  FWallBmp := TBitmap.Create;
  FFloorBmp := TBitmap.Create;

  // Chargement initial des ressources et animations
  LoadResourcesFromSpriteSheet('Skin1');
  LoadAnimationImagesFromSprite;
end;

destructor TSokoban.Destroy;
begin
  FPlayerBmpUp.Free;
  FPlayerBmpDown.Free;
  FPlayerBmpLeft.Free;
  FPlayerBmpRight.Free;
  FBoxBmp.Free;
  FBoxOnTargetBmp.Free;
  FTargetBmp.Free;
  FWallBmp.Free;
  FFloorBmp.Free;
  FSpriteSheet.Free;
  FAnimBmp1.Free;
  FAnimBmp2.Free;
  if Assigned(FAnimTimer) then
    FAnimTimer.Free;
  inherited Destroy;
end;

{ ------------------------------------------------------------------- }
{ Méthodes internes de chargement et découpage d'image }
{ ------------------------------------------------------------------- }
procedure TSokoban.LoadSprite(var Destination: TBitmap; const SrcRect: TRect);
begin
  Destination := TBitmap.Create;
  Destination.Width := FTileWidth;
  Destination.Height := FTileHeight;
  Destination.Canvas.CopyRect(Rect(0, 0, FTileWidth, FTileHeight), FSpriteSheet.Canvas, SrcRect);
end;

procedure TSokoban.LoadResourcesFromSpriteSheet(ASkin: String);
var
  SrcRect: TRect;
begin
  if Assigned(FSpriteSheet) then
    FSpriteSheet.Free;
  FSpriteSheet := TBitmap.Create;
  FSpriteSheet.LoadFromResourceName(HInstance, ASkin);

  SrcRect := Rect(0 * FTileWidth, 0, 1 * FTileWidth, FTileHeight);
  LoadSprite(FPlayerBmpUp, SrcRect);
  SrcRect := Rect(1 * FTileWidth, 0, 2 * FTileWidth, FTileHeight);
  LoadSprite(FPlayerBmpDown, SrcRect);
  SrcRect := Rect(2 * FTileWidth, 0, 3 * FTileWidth, FTileHeight);
  LoadSprite(FPlayerBmpLeft, SrcRect);
  SrcRect := Rect(3 * FTileWidth, 0, 4 * FTileWidth, FTileHeight);
  LoadSprite(FPlayerBmpRight, SrcRect);
  SrcRect := Rect(4 * FTileWidth, 0, 5 * FTileWidth, FTileHeight);
  LoadSprite(FBoxBmp, SrcRect);
  SrcRect := Rect(5 * FTileWidth, 0, 6 * FTileWidth, FTileHeight);
  LoadSprite(FBoxOnTargetBmp, SrcRect);
  SrcRect := Rect(6 * FTileWidth, 0, 7 * FTileWidth, FTileHeight);
  LoadSprite(FTargetBmp, SrcRect);
  SrcRect := Rect(7 * FTileWidth, 0, 8 * FTileWidth, FTileHeight);
  LoadSprite(FWallBmp, SrcRect);
  SrcRect := Rect(8 * FTileWidth, 0, 9 * FTileWidth, FTileHeight);
  LoadSprite(FFloorBmp, SrcRect);
end;

procedure TSokoban.ChangeSkinSprite(const ASkinResourceName: string);
begin
  try
    LoadResourcesFromSpriteSheet(ASkinResourceName);
    GetSkin := ASkinResourceName;
  except
    on E: Exception do
    begin
      ShowMessage('Erreur lors du chargement de la nouvelle sprite sheet: ' + E.Message);
      Exit;
    end;
  end;
  DrawGame;
end;

{ ------------------------------------------------------------------- }
{ Chargement des niveaux }
{ ------------------------------------------------------------------- }
procedure TSokoban.LoadLevel(const ALevel: array of string);
var
  I, J: Integer;
begin
  SetLength(FMap, Length(ALevel));
  for I := 0 to High(ALevel) do
  begin
    SetLength(FMap[I], Length(ALevel[I]));
    for J := 1 to Length(ALevel[I]) do
    begin
      FMap[I, J - 1] := ALevel[I][J];
      if (ALevel[I][J] = 'P') or (ALevel[I][J] = 'p') then
      begin
        FPlayerPos.X := J - 1;
        FPlayerPos.Y := I;
      end;
    end;
  end;
end;

procedure TSokoban.LoadLevelFromJSONResource(LevelIndex: Integer);
const
  LEVELS_RESOURCE_NAME = 'Levels';
var
  ResStream: TResourceStream;
  JSONString: string;
  JSONValue: TJSONValue;
  LevelsArray, LayoutArray: TJSONArray;
  LevelObject: TJSONObject;
  LevelStrings: TArray<string>;
  I: Integer;
  SolverValue: TJSONValue;
  Bytes: TBytes;
begin
  ResStream := TResourceStream.Create(HInstance, LEVELS_RESOURCE_NAME, RT_RCDATA);
  try
    SetLength(Bytes, ResStream.Size);
    ResStream.Position := 0;
    ResStream.ReadBuffer(Bytes[0], ResStream.Size);
    JSONString := TEncoding.UTF8.GetString(Bytes);
    JSONValue := TJSONObject.ParseJSONValue(JSONString);
    if not Assigned(JSONValue) then
      raise Exception.Create('Erreur de parsing JSON');
    try
      LevelsArray := (JSONValue as TJSONObject).GetValue<TJSONArray>('levels');
      if not Assigned(LevelsArray) then
        raise Exception.Create('Aucun niveau trouvé dans le JSON');
      FLevelsCount := LevelsArray.Count;
      FCurrentLevel := LevelIndex;
      if (LevelIndex < 0) or (LevelIndex >= LevelsArray.Count) then
        raise Exception.Create('Niveau invalide ou non trouvé');
      LevelObject := LevelsArray.Items[LevelIndex] as TJSONObject;
      SolverValue := LevelObject.Values['solver'];
      if Assigned(SolverValue) then
        FSolveur := UpperCase(SolverValue.Value)
      else
        FSolveur := '';
      LayoutArray := LevelObject.GetValue<TJSONArray>('lvl');
      if not Assigned(LayoutArray) then
        raise Exception.Create('lvl du niveau absent');
      SetLength(LevelStrings, LayoutArray.Count);
      for I := 0 to LayoutArray.Count - 1 do
        LevelStrings[I] := LayoutArray.Items[I].Value;
      LoadLevel(LevelStrings);
    finally
      JSONValue.Free;
    end;
  finally
    ResStream.Free;
  end;
end;

{ ------------------------------------------------------------------- }
{ Sauvegarde et chargement via le registre }
{ ------------------------------------------------------------------- }
procedure TSokoban.SaveGameToRegistry;
var
  Reg: TRegistry;
begin
  Reg := TRegistry.Create;
  try
    Reg.RootKey := HKEY_CURRENT_USER;
    if Reg.OpenKey('Software\Sokoban', True) then
    begin
      Reg.WriteInteger('CurrentLevel', FCurrentLevel);
      Reg.WriteInteger('CurrentPoints', FPoints);
      Reg.WriteString('CurrentSkin', FSkin);
    end;
  finally
    Reg.Free;
  end;
end;

procedure TSokoban.ResetGameToRegistry;
var
  Reg: TRegistry;
begin
  Reg := TRegistry.Create;
  try
    Reg.RootKey := HKEY_CURRENT_USER;
    if Reg.OpenKey('Software\Sokoban', True) then
    begin
      Reg.WriteInteger('CurrentLevel', 0);
      Reg.WriteInteger('CurrentPoints', 0);
      Reg.WriteString('CurrentSkin', 'Skin1');
    end;
  finally
    Reg.Free;
  end;
end;

procedure TSokoban.LoadGameFromRegistry;
var
  Reg: TRegistry;
  Level: Integer;
  SkinValue: string;
begin
  Reg := TRegistry.Create;
  try
    Reg.RootKey := HKEY_CURRENT_USER;
    if Reg.OpenKey('Software\Sokoban', False) then
    begin
      if Reg.ValueExists('CurrentLevel') then
        Level := Reg.ReadInteger('CurrentLevel')
      else
        Level := 0;

      FCurrentLevel := Level;
      if Reg.ValueExists('CurrentPoints') then
        try
          FPoints := Reg.ReadInteger('CurrentPoints');

          if FPoints < 0 then
            FPoints := 0;
        except
          FPoints := 0;
        end
      else
        FPoints := 0;
      if Reg.ValueExists('CurrentSkin') then
        SkinValue := Reg.ReadString('CurrentSkin')
      else
        SkinValue := 'Skin1';
      FSkin := SkinValue;
      LoadLevelFromJSONResource(FCurrentLevel);
      ChangeSkinSprite(FSkin);

      FPlayerDirection := GetPlayerDirection;
      DrawGame;
    end
    else
    begin
      FCurrentLevel := 0;
      FPoints := 0;
      FSkin := 'Skin1';
      LoadLevelFromJSONResource(FCurrentLevel);
      ChangeSkinSprite(FSkin);
      DrawGame;
    end;
  finally
    Reg.Free;
  end;
end;

{ ------------------------------------------------------------------- }
{ Affichage et dessin }
{ ------------------------------------------------------------------- }
procedure TSokoban.DrawText(const AText: string);
const
  APosY = 10;
var
  TxtWidth, TxtHeight, TxtX: Integer;
  ClearRect: TRect;
begin
  with FImage.Picture.Bitmap.Canvas do
  begin
    Font.Name := 'Arial';
    Font.Size := 10;
    Font.Style := [fsBold];
    Font.Color := clBlack;
    TxtWidth := TextWidth(AText);
    TxtHeight := TextHeight(AText);
    ClearRect := Rect(0, APosY, FImage.Picture.Bitmap.Width, APosY + TxtHeight);
    Brush.Color := StyleServices.GetStyleColor(scWindow);
    FillRect(ClearRect);
    TxtX := (FImage.Picture.Bitmap.Width - TxtWidth) div 2;
    TextOut(TxtX, APosY, AText);
  end;
  FImage.Repaint;
end;

procedure TSokoban.DrawBottomText(const AText: string);
var
  TxtHeight, TxtX, TxtY: Integer;
  ClearRect: TRect;
begin
  with FImage.Picture.Bitmap.Canvas do
  begin
    Font.Name := 'Arial';
    Font.Size := 10;
    Font.Style := [fsBold];
    Font.Color := clBlack;
    TxtHeight := TextHeight(AText);
    TxtX := 10;
    TxtY := FImage.Picture.Bitmap.Height - TxtHeight - 10;
    TextOut(TxtX, TxtY, AText);
  end;
  FImage.Repaint;
  Application.ProcessMessages;
  Sleep(2000);
  ClearRect := Rect(0, FImage.Picture.Bitmap.Height - TxtHeight - 10, FImage.Picture.Bitmap.Width,
    FImage.Picture.Bitmap.Height);
  with FImage.Picture.Bitmap.Canvas do
  begin
    Brush.Color := StyleServices.GetStyleColor(scWindow);
    FillRect(ClearRect);
  end;
  FImage.Repaint;
  DrawPoints;
end;

procedure TSokoban.DrawPoints;
var
  PointsStr: string;
  TxtHeight, TxtX, TxtY: Integer;
begin
  if Assigned(FAnimTimer) then
    Exit;

  if FPoints < 0 then
    FPoints := 0;

  PointsStr := 'XP : ' + IntToStr(FPoints);
  with FImage.Picture.Bitmap.Canvas do
  begin
    Font.Name := 'Arial';
    Font.Size := 10;
    Font.Style := [fsBold];
    Font.Color := clBlack;
    TxtHeight := TextHeight(PointsStr);
    TxtX := 10;
    TxtY := FImage.Picture.Bitmap.Height - TxtHeight - 10;
    TextOut(TxtX, TxtY, PointsStr);
  end;
  FImage.Repaint;
end;

procedure TSokoban.DrawGame;
var
  I, J: Integer;
  RectDest, MapRect: TRect;
  MapWidth, MapHeight: Integer;
  OffsetX, OffsetY: Integer;
  LevelStr: string;
  firstWall, lastWall: Integer;
  Pushes: Integer;
begin
  FImage.Picture.Bitmap.Width := FImage.Width;
  FImage.Picture.Bitmap.Height := FImage.Height;
  with FImage.Picture.Bitmap.Canvas do
  begin
    Brush.Color := StyleServices.GetStyleColor(scWindow);
    FillRect(Rect(0, 0, FImage.Picture.Bitmap.Width, FImage.Picture.Bitmap.Height));
    if Length(FMap) > 0 then
      MapWidth := Length(FMap[0]) * FTileWidth
    else
      MapWidth := 0;
    MapHeight := Length(FMap) * FTileHeight;
    OffsetX := (FImage.Picture.Bitmap.Width - MapWidth) div 2;
    OffsetY := (FImage.Picture.Bitmap.Height - MapHeight) div 2;
    MapRect := Rect(OffsetX, OffsetY, OffsetX + MapWidth, OffsetY + MapHeight);
    Brush.Color := StyleServices.GetStyleColor(scPanel);
    FillRect(MapRect);
    for I := Low(FMap) to High(FMap) do
    begin
      firstWall := -1;
      lastWall := -1;
      for J := Low(FMap[I]) to High(FMap[I]) do
      begin
        if FMap[I, J] = '#' then
        begin
          if firstWall = -1 then
            firstWall := J;
          lastWall := J;
        end;
      end;
      for J := Low(FMap[I]) to High(FMap[I]) do
      begin
        RectDest := Rect(OffsetX + J * FTileWidth, OffsetY + I * FTileHeight,
          OffsetX + (J + 1) * FTileWidth, OffsetY + (I + 1) * FTileHeight);
        case FMap[I, J] of
          '#':
            Draw(RectDest.Left, RectDest.Top, FWallBmp);
          'T':
            Draw(RectDest.Left, RectDest.Top, FTargetBmp);
          'P':
            Draw(RectDest.Left, RectDest.Top, GetPlayerBitmap);
          'p':
            begin
              Draw(RectDest.Left, RectDest.Top, FTargetBmp);
              Draw(RectDest.Left, RectDest.Top, GetPlayerBitmap);
            end;
          'B':
            Draw(RectDest.Left, RectDest.Top, FBoxBmp);
          'b':
            Draw(RectDest.Left, RectDest.Top, FBoxOnTargetBmp);
          ' ':
            begin
              if (firstWall <> -1) and ((J < firstWall) or (J > lastWall)) then
              begin
                Brush.Color := StyleServices.GetStyleColor(scWindow);
                FillRect(RectDest);
              end
              else
                Draw(RectDest.Left, RectDest.Top, FFloorBmp);
            end;
        else
          Draw(RectDest.Left, RectDest.Top, FFloorBmp);
        end;
      end;
    end;
  end;
  Pushes := Length(FSolveur);
  if (FMoveCount >= Pushes) and (not IsLevelCompleted) then
  begin
    LevelStr := 'Oups, Perdu ! -2 XP - Limite de déplacement atteinte';

    if FPoints > 0 then
      Dec(FPoints, 2);
  end
  else
    LevelStr := GetDifficultyLevel + ' : ' + IntToStr(FCurrentLevel + 1) + ' / ' +
      IntToStr(FLevelsCount) + ' - Pushes : ' + IntToStr(FMoveCount) + ' / ' +
      IntToStr(Length(FSolveur));
  DrawText(LevelStr);
  DrawPoints;
  FImage.Repaint;

  if (FMoveCount >= Pushes) and (not IsLevelCompleted) then
    RestartLevel;
end;

function TSokoban.GetPlayerBitmap: TBitmap;
begin
  case FPlayerDirection of
    pdUp:
      Result := FPlayerBmpUp;
    pdDown:
      Result := FPlayerBmpDown;
    pdLeft:
      Result := FPlayerBmpLeft;
    pdRight:
      Result := FPlayerBmpRight;
  else
    Result := FPlayerBmpDown;
  end;
end;

function TSokoban.GetDifficultyLevel: string;
var
  SolverLength: Integer;
begin
  SolverLength := Length(FSolveur);
  if SolverLength >= 200 then
  begin
    Result := 'Niveau : Démon';
    FPointLevel := 12;
  end
  else if SolverLength >= 100 then
  begin
    Result := 'Niveau : Hard';
    FPointLevel := 10;
  end
  else if SolverLength >= 80 then
  begin
    Result := 'Niveau : Extrême';
    FPointLevel := 8;
  end
  else if SolverLength >= 60 then
  begin
    Result := 'Niveau : Très difficile';
    FPointLevel := 6;
  end
  else if SolverLength >= 40 then
  begin
    Result := 'Niveau : Difficile';
    FPointLevel := 4;
  end
  else if SolverLength >= 20 then
  begin
    Result := 'Niveau : Moyen';
    FPointLevel := 2;
  end
  else
  begin
    Result := 'Niveau : Facile';
    FPointLevel := 1;
  end;
end;

{ ------------------------------------------------------------------- }
{ Animation }
{ ------------------------------------------------------------------- }
procedure TSokoban.AnimBottomTimer(Sender: TObject);
var
  Speed, ImgY: Integer;
  FrameBitmap: TBitmap;
begin
  Speed := 5;
  case FAnimDirection of
    adLeftToRight:
      Inc(FAnimX, Speed);
    adRightToLeft:
      Dec(FAnimX, Speed);
  end;
  FAnimCurrentFrame := (FAnimCurrentFrame + 1) mod 2;
  if FAnimCurrentFrame = 0 then
    FrameBitmap := FAnimBmp1
  else
    FrameBitmap := FAnimBmp2;
  ImgY := FImage.Picture.Bitmap.Height - FAnimFrameHeight;
  with FImage.Picture.Bitmap.Canvas do
  begin
    Brush.Style := bsSolid;
    Brush.Color := StyleServices.GetStyleColor(scWindow);
    FillRect(Rect(0, ImgY, FImage.Width, FImage.Height));
    Draw(FAnimX, ImgY, FrameBitmap);
  end;
  FImage.Repaint;
  if (FAnimDirection = adLeftToRight) and ((FAnimX + FAnimFrameWidth) >= FImage.Width) then
  begin
    FAnimTimer.Enabled := False;
    FAnimTimer.Free;
    FAnimTimer := nil;
  end
  else if (FAnimDirection = adRightToLeft) and (FAnimX <= 0) then
  begin
    FAnimTimer.Enabled := False;
    FAnimTimer.Free;
    FAnimTimer := nil;
  end;
end;

procedure TSokoban.LoadAnimationImagesFromSprite;
var
  AnimSpriteSheet: TBitmap;
  SrcRect: TRect;
begin
  AnimSpriteSheet := TBitmap.Create;
  try
    case FAnimDirection of
      adRightToLeft:
        AnimSpriteSheet.LoadFromResourceName(HInstance, 'Anim_Left');
      adLeftToRight:
        AnimSpriteSheet.LoadFromResourceName(HInstance, 'Anim_Right');
    end;
    SrcRect := Rect(0, 0, FAnimFrameWidth, FAnimFrameHeight);
    if Assigned(FAnimBmp1) then
      FAnimBmp1.Free;
    FAnimBmp1 := TBitmap.Create;
    FAnimBmp1.PixelFormat := AnimSpriteSheet.PixelFormat;
    FAnimBmp1.Width := FAnimFrameWidth;
    FAnimBmp1.Height := FAnimFrameHeight;
    FAnimBmp1.Canvas.CopyRect(Rect(0, 0, FAnimFrameWidth, FAnimFrameHeight),
      AnimSpriteSheet.Canvas, SrcRect);
    SrcRect := Rect(FAnimFrameWidth, 0, 2 * FAnimFrameWidth, FAnimFrameHeight);
    if Assigned(FAnimBmp2) then
      FAnimBmp2.Free;
    FAnimBmp2 := TBitmap.Create;
    FAnimBmp2.PixelFormat := AnimSpriteSheet.PixelFormat;
    FAnimBmp2.Width := FAnimFrameWidth;
    FAnimBmp2.Height := FAnimFrameHeight;
    FAnimBmp2.Canvas.CopyRect(Rect(0, 0, FAnimFrameWidth, FAnimFrameHeight),
      AnimSpriteSheet.Canvas, SrcRect);
  finally
    AnimSpriteSheet.Free;
  end;
end;

procedure TSokoban.StartBottomAnimation(const ADirection: TAnimationDirection);
begin
  FAnimDirection := ADirection;
  LoadAnimationImagesFromSprite;
  case ADirection of
    adLeftToRight:
      FAnimX := 0;
    adRightToLeft:
      FAnimX := FImage.Picture.Bitmap.Width - FAnimFrameWidth;
  end;
  FAnimCurrentFrame := 0;
  if Assigned(FAnimTimer) then
  begin
    FAnimTimer.Free;
    FAnimTimer := nil;
  end;
  FAnimTimer := TTimer.Create(nil);
  FAnimTimer.Interval := 30;
  FAnimTimer.OnTimer := AnimBottomTimer;
  FAnimTimer.Enabled := True;
end;

procedure TSokoban.WaitForAnimation;
begin
  while Assigned(FAnimTimer) do
    Application.ProcessMessages;
end;

procedure TSokoban.PlayMoveSound(const ResName: string);
var
  ResStream: TResourceStream;
  MemStream: TMemoryStream;
begin
  ResStream := TResourceStream.Create(HInstance, ResName, RT_RCDATA);
  try
    MemStream := TMemoryStream.Create;
    try
      ResStream.Seek(0, soBeginning);
      MemStream.CopyFrom(ResStream, ResStream.Size);
      PlaySound(MemStream.Memory, 0, SND_MEMORY or SND_ASYNC);
    finally
      MemStream.Free;
    end;
  finally
    ResStream.Free;
  end;
end;

{ ------------------------------------------------------------------- }
{ Gestion des interactions et déplacements }
{ ------------------------------------------------------------------- }
procedure TSokoban.HandleMouseClick(X, Y: Integer);
var
  MapWidth, MapHeight, OffsetX, OffsetY: Integer;
  PlayerLeft, PlayerTop, PlayerCenterX, PlayerCenterY: Integer;
  DeltaX, DeltaY: Integer;
begin
  if Length(FMap) = 0 then
  begin
    ShowMessage('Carte non chargée');
    Exit;
  end;
  MapWidth := Length(FMap[0]) * FTileWidth;
  MapHeight := Length(FMap) * FTileHeight;
  OffsetX := (FImage.Picture.Bitmap.Width - MapWidth) div 2;
  OffsetY := (FImage.Picture.Bitmap.Height - MapHeight) div 2;
  if (X < OffsetX) or (X > OffsetX + MapWidth) or (Y < OffsetY) or (Y > OffsetY + MapHeight) then
    Exit;
  PlayerLeft := OffsetX + FPlayerPos.X * FTileWidth;
  PlayerTop := OffsetY + FPlayerPos.Y * FTileHeight;
  PlayerCenterX := PlayerLeft + FTileWidth div 2;
  PlayerCenterY := PlayerTop + FTileHeight div 2;
  DeltaX := X - PlayerCenterX;
  DeltaY := Y - PlayerCenterY;
  if Abs(DeltaX) > Abs(DeltaY) then
  begin
    if DeltaX > 0 then
      MovePlayer(1, 0)
    else
      MovePlayer(-1, 0);
  end
  else
  begin
    if DeltaY > 0 then
      MovePlayer(0, 1)
    else
      MovePlayer(0, -1);
  end;
end;

procedure TSokoban.MovePlayer(DeltaX, DeltaY: Integer);
var
  newX, newY, pushX, pushY: Integer;
  OldPos: TCoord;
begin
  if Assigned(FAnimTimer) then
    Exit;

  SaveUndoState;
  OldPos := FPlayerPos;
  if DeltaX > 0 then
    FPlayerDirection := pdRight
  else if DeltaX < 0 then
    FPlayerDirection := pdLeft
  else if DeltaY > 0 then
    FPlayerDirection := pdDown
  else if DeltaY < 0 then
    FPlayerDirection := pdUp;
  newX := FPlayerPos.X + DeltaX;
  newY := FPlayerPos.Y + DeltaY;
  if (newY < 0) or (newY > High(FMap)) or (newX < 0) or (newX > High(FMap[newY])) then
    Exit;
  case FMap[newY, newX] of
    '#':
      Exit;
    ' ', 'T':
      begin
        if FMap[newY, newX] = 'T' then
          FMap[newY, newX] := 'p'
        else
          FMap[newY, newX] := 'P';
        if FMap[FPlayerPos.Y, FPlayerPos.X] = 'p' then
          FMap[FPlayerPos.Y, FPlayerPos.X] := 'T'
        else
          FMap[FPlayerPos.Y, FPlayerPos.X] := ' ';
        FPlayerPos.X := newX;
        FPlayerPos.Y := newY;
      end;
    'B', 'b':
      begin
        pushX := newX + DeltaX;
        pushY := newY + DeltaY;
        if (pushY < 0) or (pushY > High(FMap)) or (pushX < 0) or (pushX > High(FMap[pushY])) then
          Exit;
        if CharInSet(FMap[pushY, pushX], [' ', 'T']) then
        begin
          if FMap[pushY, pushX] = 'T' then
            FMap[pushY, pushX] := 'b'
          else
            FMap[pushY, pushX] := 'B';
          if CharInSet(FMap[newY, newX], ['b']) then
            FMap[newY, newX] := 'p'
          else
            FMap[newY, newX] := 'P';
          if FMap[FPlayerPos.Y, FPlayerPos.X] = 'p' then
            FMap[FPlayerPos.Y, FPlayerPos.X] := 'T'
          else
            FMap[FPlayerPos.Y, FPlayerPos.X] := ' ';
          FPlayerPos.X := newX;
          FPlayerPos.Y := newY;
        end
        else
          Exit;
      end;
  end;

  if (FPlayerPos.X <> OldPos.X) or (FPlayerPos.Y <> OldPos.Y) then
    Inc(FMoveCount);

  if not FUsedAutoSolver then
    PlayMoveSound('Move');

  UpdateGame;
end;

procedure TSokoban.SaveUndoState;
var
  I, J: Integer;
begin
  SetLength(FMapBackup, Length(FMap));
  for I := 0 to High(FMap) do
  begin
    SetLength(FMapBackup[I], Length(FMap[I]));
    for J := 0 to High(FMap[I]) do
      FMapBackup[I][J] := FMap[I][J];
  end;
  FPlayerPosBackup := FPlayerPos;
  FMoveCountBackup := FMoveCount;
end;

procedure TSokoban.UndoMove;
var
  I, J: Integer;
begin
  if Length(FMapBackup) = 0 then
  begin
    DrawBottomText('Oups, Aucun retour en arrière n’est possible !');
    Exit;
  end;
  if FPoints <= 0 then
  begin
    DrawBottomText('Oups, Tu n’as pas assez de XP pour utiliser le retour en arrière !');
    Exit;
  end;

  Dec(FPoints, 1);

  DrawPoints;
  SetLength(FMap, Length(FMapBackup));
  for I := 0 to High(FMapBackup) do
  begin
    SetLength(FMap[I], Length(FMapBackup[I]));
    for J := 0 to High(FMapBackup[I]) do
      FMap[I][J] := FMapBackup[I][J];
  end;
  FPlayerPos := FPlayerPosBackup;
  FMoveCount := FMoveCountBackup;
  DrawGame;
end;

{ ------------------------------------------------------------------- }
{ Changement de niveau et solveur }
{ ------------------------------------------------------------------- }
procedure TSokoban.UpdateGame;
begin
  if IsLevelCompleted then
  begin
    DrawGame;
    Application.ProcessMessages;
    Sleep(200);

    if not FUsedAutoSolver then
    begin
      PlayMoveSound('Winner');
      Inc(FPoints, FPointLevel);
      DrawText('Niveau terminé ! +' + IntToStr(FPointLevel) + ' XP - Bien joué !');
    end
    else
      DrawText('Niveau terminé ! -' + IntToStr(FPointLevel) + ' XP - Oups !');

    FImage.Repaint;
    NextLevel;
  end;
end;

procedure TSokoban.NextLevel;
begin
{$IFDEF RELEASE}
  StartBottomAnimation(adLeftToRight);
  WaitForAnimation;
{$ENDIF}
  if FCurrentLevel < (FLevelsCount - 1) then
    Inc(FCurrentLevel)
  else
    FCurrentLevel := 0;

  InternalLoadLevel(FCurrentLevel);
end;

procedure TSokoban.PreviousLevel;
begin
  if FCurrentLevel > 0 then
  begin
    Dec(FCurrentLevel);
    InternalLoadLevel(FCurrentLevel);
  end;
end;

procedure TSokoban.LevelByIndex(Level: Integer);
begin
  StartBottomAnimation(adLeftToRight);
  WaitForAnimation;
  FCurrentLevel := Level;
  InternalLoadLevel(FCurrentLevel);
end;

procedure TSokoban.RestartLevel;
begin
  if Assigned(FAnimTimer) then
    Exit;

  StartBottomAnimation(adRightToLeft);
  WaitForAnimation;
  InternalLoadLevel(FCurrentLevel);
end;

procedure TSokoban.InternalLoadLevel(LevelIndex: Integer);
begin
  SetLength(FMapBackup, 0);
  FUsedAutoSolver := False;
  LoadLevelFromJSONResource(LevelIndex);
  FPlayerDirection := GetPlayerDirection;
  FMoveCount := 0;
  DrawGame;
end;

function TSokoban.GetPlayerDirection: TPlayerDirection;
var
  move: Char;
begin
  move := Copy(FSolveur, 1, 1)[1];

  case move of
    'R':
      Result := pdRight;
    'L':
      Result := pdLeft;
    'D':
      Result := pdDown;
    'U':
      Result := pdUp;
  else
    Result := pdDown;
  end;

end;

procedure TSokoban.Solveur;
var
  I: Integer;
  move: Char;
begin
{$IFDEF RELEASE}
  if FPoints < Length(FSolveur) then
  begin
    DrawBottomText('Oups, tu n’as pas assez de XP pour résoudre ce niveau !');
    Exit;
  end;

  Dec(FPoints, FPointLevel);
{$ENDIF}
  FUsedAutoSolver := True;
  LoadLevelFromJSONResource(FCurrentLevel);
  FMoveCount := 0;
  DrawGame;
  for I := 1 to Length(FSolveur) do
  begin
    move := FSolveur[I];
    case move of
      'R':
        MovePlayer(1, 0);
      'L':
        MovePlayer(-1, 0);
      'D':
        MovePlayer(0, 1);
      'U':
        MovePlayer(0, -1);
    end;
    DrawGame;
    Application.ProcessMessages;
    Sleep(150);

    if IsLevelCompleted then
      Break;
  end;
end;

procedure TSokoban.IndSolveur;
var
  I, HalfPoints, CurrentLineLength: Integer;
  Token, IndiceFinal: String;
  move: Char;
begin
{$IFDEF RELEASE}
  HalfPoints := Round(Length(FSolveur) / 2);
  if FPoints < HalfPoints then
  begin
    DrawBottomText('Oups, tu n’as pas assez de XP pour afficher un indice !');
    Exit;
  end;

  Dec(FPoints, HalfPoints);
{$ENDIF}
  LoadLevelFromJSONResource(FCurrentLevel);
  FMoveCount := 0;
  DrawGame;

  IndiceFinal := '';
  CurrentLineLength := 0;
  for I := 1 to Length(FSolveur) do
  begin
    move := FSolveur[I];
    case move of
      'R':
        Token := '[' + Char($2192) + '] ';
      'L':
        Token := '[' + Char($2190) + '] ';
      'D':
        Token := '[' + Char($2193) + '] ';
      'U':
        Token := '[' + Char($2191) + '] ';
    else
      Token := '';
    end;

    if (CurrentLineLength + Length(Token)) > 80 then
    begin
      IndiceFinal := IndiceFinal + sLineBreak;
      CurrentLineLength := 0;
    end;

    IndiceFinal := IndiceFinal + Token;
    Inc(CurrentLineLength, Length(Token));
  end;

  ShowMessage(IndiceFinal);
end;

procedure TSokoban.ShareLevelImage;
var
  Level, PicturesPath: String;
begin
  try
    Level := Format('Sokoban N° %d.bmp', [FCurrentLevel + 1]);
    PicturesPath := TPath.GetPicturesPath + '\' + Level;
    FImage.Picture.SaveToFile(PicturesPath);
    ShellExecute(Application.MainForm.Handle, 'open', PChar(PicturesPath), nil, nil, SW_SHOWNORMAL);
  except
    ShowMessage('Erreur lors de l''enregistrement de l''image !');
  end;
end;

function TSokoban.IsLevelCompleted: Boolean;
var
  I, J: Integer;
begin
  for I := 0 to High(FMap) do
    for J := 0 to High(FMap[I]) do
      if FMap[I][J] = 'B' then
      begin
        Result := False;
        Exit;
      end;
  Result := True;
end;

end.
