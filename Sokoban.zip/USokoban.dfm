object FSokoban: TFSokoban
  Left = 0
  Top = 0
  BorderIcons = [biSystemMenu, biMinimize]
  BorderStyle = bsSingle
  Caption = 'Sokoban'
  ClientHeight = 414
  ClientWidth = 478
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Menu = MainMenu
  Position = poDesktopCenter
  OnCloseQuery = FormCloseQuery
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  OnKeyDown = FormKeyDown
  TextHeight = 15
  object Game: TImage
    Left = 0
    Top = 0
    Width = 478
    Height = 414
    Align = alClient
    OnMouseDown = GameMouseDown
    ExplicitLeft = 88
    ExplicitTop = 80
    ExplicitWidth = 105
    ExplicitHeight = 105
  end
  object MainMenu: TMainMenu
    AutoHotkeys = maManual
    Left = 416
    Top = 24
    object MainGame: TMenuItem
      Caption = 'Menu'
      object NewGame: TMenuItem
        Caption = 'Nouvelle partie'
        OnClick = NewGameClick
      end
      object N1: TMenuItem
        Caption = '-'
      end
      object SkinLevel: TMenuItem
        Caption = 'Changer de skin'
        OnClick = SkinLevelClick
      end
      object QuitGame: TMenuItem
        Caption = 'Quitter le jeu'
        OnClick = QuitGameClick
      end
    end
    object MainLevel: TMenuItem
      Caption = 'Partie'
      object IndSolverLevel: TMenuItem
        Caption = 'Afficher un indice'
        OnClick = IndSolverLevelClick
      end
      object SolverLevel: TMenuItem
        Caption = 'R'#233'soudre ce niveau'
        OnClick = SolverLevelClick
      end
      object UndoMove: TMenuItem
        Caption = 'Retour en arri'#232're'
        OnClick = UndoMoveClick
      end
      object N2: TMenuItem
        Caption = '-'
      end
      object RestartLevel: TMenuItem
        Caption = 'Recommencer la partie'
        OnClick = RestartLevelClick
      end
      object ShareLevel: TMenuItem
        Caption = 'Partager mon niveau'
        OnClick = ShareLevelClick
      end
    end
    object MainDebug: TMenuItem
      Caption = 'Debug'
      object LevelByIndex: TMenuItem
        Caption = 'LevelByIndex'
        OnClick = LevelByIndexClick
      end
      object NextLevel: TMenuItem
        Caption = 'NextLevel'
        OnClick = NextLevelClick
      end
      object PreviousLevel: TMenuItem
        Caption = 'PreviousLevel'
        OnClick = PreviousLevelClick
      end
    end
    object MainAbout: TMenuItem
      Caption = '?'
      object InfoGame: TMenuItem
        Caption = 'M'#233'canismes de Jeu'
        OnClick = InfoGameClick
      end
      object InfoLevel: TMenuItem
        Caption = 'Niveaux de difficult'#233
        OnClick = InfoLevelClick
      end
      object InfoPoints: TMenuItem
        Caption = 'Points d'#39'exp'#233'rience (XP)'
        OnClick = InfoPointsClick
      end
    end
  end
end
